

javac *.java && java org.junit.runner.JUnitCore PartTwoTestCases
